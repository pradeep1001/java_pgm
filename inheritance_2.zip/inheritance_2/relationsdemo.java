class car
 { 
    private String color; 
    private int maxSpeed; 
      public void carInfo()
    {
      System.out.println( " car color  " + color + " max speed = "+ maxSpeed );   
    }
   public void setColor(String color)
    {
      this.color = color ;    
    }
	public void setMaxSpeed(int  maxSpeed)
    {
      this.maxSpeed =  maxSpeed;    
    }
   
} 
 
   
	class Maruti extends car
  {
    
        public void MarutiStartDemo()
    {
        Engine a = new Engine();
        a.start();  
    }
 } 
 class Engine
  {
        public void start()
     {
          System.out.println( " engine started :    " );  
     }
     public void stop()
     {
          System.out.println( " engine stoped :    " );  
     }
   
 }
   		class relationsdemo  
  { 
       public static void  main(String ar[] )
    {
          Maruti b = new Maruti();
          b.setColor("RED ");
          b.setMaxSpeed(200);
          b.carInfo();
          b.MarutiStartDemo();
     }  
  }
