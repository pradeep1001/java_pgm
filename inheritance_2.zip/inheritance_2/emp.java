class Depart
{
  int did; 
  String dname ; 
    void fun()
   {
     did = 10;
     dname = "sales ";
   }
}

 class emp extends Depart
  {
    int eid ;
    String ename ; 
    double sal ;
      void accept()
    {
      fun();
      eid = 100;
      ename = "john" ;
      sal = 1000; 
   }
         void disp()
     { 
         System.out.println( "   " + did);  
         System.out.println( "   " + dname);
         System.out.println( "   " + eid);
         System.out.println( "   " + ename);
         System.out.println( "   " + sal);
      
    }
	    public static void  main(String ar[] )
  	{ 
             emp e1 = new emp();
            e1.accept();
            e1.disp(); 

        }
}